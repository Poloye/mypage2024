-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2024 at 03:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `location_711`
--

CREATE TABLE `location_711` (
  `store_id` varchar(255) NOT NULL,
  `store_name` varchar(255) NOT NULL,
  `lat` varchar(255) NOT NULL,
  `lon` varchar(255) NOT NULL,
  `tel` int(225) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location_711`
--

INSERT INTO `location_711` (`store_id`, `store_name`, `lat`, `lon`, `tel`, `address`) VALUES
('04446', '7-Eleven สาขา PTTOR ชัยพฤกษ์', '13.89265047969105', '100.44977615920475', 910024446, '15/26 หมู่1 ถ. ราชพฤกษ์ ตำบลบางพูด อำเภอปากเกร็ด นนทบุรี 11120'),
('06649', '7-Eleven สาขา PTTOR ประดับดาว', '13.8906924536079018', '100.4508812294060', 0, 'ตำบล ท่าอิฐ อำเภอปากเกร็ด นนทบุรี 11120'),
('16279', '7-Eleven สาขา ชุมชนบางประดับดาว ราชพฤกษ์ ', '13.894952180665902', '100.4535419806831', 0, 'ตำบล ท่าอิฐ อำเภอปากเกร็ด นนทบุรี 11120'),
('14548', '7-Eleven สาขา สามแยกท่าอิฐ', '13.893181643484551', '100.46273659304828', 0, 'ตำบล ท่าอิฐ อำเภอปากเกร็ด นนทบุรี 11120'),
('14607', '7-Eleven สาขา ชุมชนสิงห์ทอง-อ้อมเกร็ด', '13.90082106004787', '100.45448347021336', 815675688, 'ตำบล อ้อมเกร็ด อำเภอปากเกร็ด นนทบุรี 11120'),
('09988', '7-Eleven สาขา ธาราสแควร์', '13.90282333578746', '100.5326381854362', 0, '58/19 หมู่2 ซอย แจ้งวัฒนะ-ปากเกร็ด 19 ตำบลบางตลาด อำเภอปากเกร็ด นนทบุรี 11120');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- Add 22/05/2024 For seting primary key----
ALTER TABLE `location_711`
  ADD PRIMARY KEY (`store_id`);
